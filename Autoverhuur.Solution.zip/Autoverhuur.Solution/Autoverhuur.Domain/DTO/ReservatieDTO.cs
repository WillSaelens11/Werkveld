﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoverhuur.Domain.DTO
{
    public class ReservatieDTO
    {
        public int ReservatieId { get; }
        public string KlantNaam { get; }
        public string VestigingNaam { get; }
        public string AutoModel { get; }
        public DateTime StartDatum { get; }
        public DateTime EindDatum { get; }

        public ReservatieDTO(int reservatieId, string klantNaam, string vestigingNaam, string autoModel, DateTime startDatum, DateTime eindDatum)
        {
            ReservatieId = reservatieId;
            KlantNaam = klantNaam ?? throw new ArgumentNullException(nameof(klantNaam));
            VestigingNaam = vestigingNaam ?? throw new ArgumentNullException(nameof(vestigingNaam));
            AutoModel = autoModel ?? throw new ArgumentNullException(nameof(autoModel));
            StartDatum = startDatum;
            EindDatum = eindDatum;
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Interfaces;

namespace Autoverhuur.Domain
{
    public class DomainManager
    {
        private readonly IKlantRepository _klantRepository;
        private readonly IAutoRepository _autoRepository;
        private readonly IVestigingRepository _vestigingRepository;
        private readonly IReservatieRepository _reservatieRepository;

        public DomainManager(
            IKlantRepository klantRepository,
            IVestigingRepository vestigingRepository,
            IAutoRepository autoRepository,
            IReservatieRepository reservatieRepository)
        {
            _klantRepository = klantRepository;
            _vestigingRepository = vestigingRepository;
            _autoRepository = autoRepository;
            _reservatieRepository = reservatieRepository;
        }

        // KLANTEN
        public List<Klant> GeefAlleKlanten() => _klantRepository.GeefAlleKlanten();
        public void VoegKlantToe(Klant klant) => _klantRepository.VoegKlantToe(klant);

        // VESTIGINGEN
        public List<Vestiging> GeefAlleVestigingen() => _vestigingRepository.GeefAlleVestigingen();
        public void VoegVestigingToe(Vestiging vestiging) => _vestigingRepository.VoegVestigingToe(vestiging);

        // AUTOS
        public List<Auto> GeefAlleAutos() => _autoRepository.GeefAlleAutos();
        public void VoegAutoToe(Auto auto) => _autoRepository.VoegAutoToe(auto);

        // RESERVATIES
        public List<Reservatie> GeefAlleReservaties() => _reservatieRepository.GeefAlleReservaties();
        public int VoegReservatieToe(Reservatie reservatie) => _reservatieRepository.VoegReservatieToe(reservatie);

        public List<Auto> ZoekBeschikbareAutos(int vestigingId, DateTime start, DateTime eind, int? minZitplaatsen = null)
        {
            var autos = _autoRepository.GeefBeschikbareAutos(vestigingId, start, eind);

            if (minZitplaatsen.HasValue)
            {
                autos = autos.Where(a => a.Zitplaatsen >= minZitplaatsen.Value).ToList();
            }

            return autos;
        }

        public List<Reservatie> ZoekReservaties(string klantnaam, DateTime? datum, int? vestigingId)
        {
            return _reservatieRepository.ZoekReservaties(klantnaam, datum, vestigingId);
        }

        public (Reservatie? vorige, Reservatie? volgende) GeefVorigeEnVolgendeReservatie(int autoId, DateTime tijdstip)
        {
            return _reservatieRepository.GeefVorigeEnVolgendeReservatie(autoId, tijdstip);
        }

        public Klant GeefKlant(int id)
        {
            return _klantRepository.GeefKlant(id);
        }

        public void VerwijderReservatie(int id)
        {
            _reservatieRepository.VerwijderReservatie(id);
        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Autoverhuur.Domain.Exceptions
{
    public class AutoException : DomeinException
    {
        public AutoException(string message) : base(message) { }
    }
}

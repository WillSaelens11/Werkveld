﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Autoverhuur.Domain.Exceptions
{
    public abstract class DomeinException : Exception
    {
        protected DomeinException(string message) : base(message) { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoverhuur.Domain.Exceptions
{
    public class KlantException : DomeinException
    {
        public KlantException(string message) : base(message) { }
    }
}

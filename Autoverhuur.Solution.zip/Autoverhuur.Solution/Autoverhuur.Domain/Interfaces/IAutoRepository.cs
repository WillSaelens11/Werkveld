﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Domain.Interfaces
{
    public interface IAutoRepository
    {
        List<Auto> GeefAlleAutos();
        void VoegAutoToe(Auto auto);
        //void VerwijderAlleAutos();

        List<Auto> GeefBeschikbareAutos(int vestigingId, DateTime start, DateTime eind);
    }
}

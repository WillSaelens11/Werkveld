﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Domain.Interfaces
{
    public interface IKlantRepository
    {
        List<Klant> GeefAlleKlanten();
        void VoegKlantToe(Klant klant);

        Klant GeefKlant(int id);

    }
}


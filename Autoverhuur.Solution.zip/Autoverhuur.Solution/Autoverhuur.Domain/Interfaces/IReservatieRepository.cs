﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Domain.Interfaces
{
    public interface IReservatieRepository
    {
        List<Reservatie> GeefAlleReservaties();
        int VoegReservatieToe(Reservatie reservatie);

        void VerwijderReservatie(int id);
        List<Reservatie> ZoekReservaties(string klantnaam, DateTime? datum, int? vestigingId);
        (Reservatie? vorige, Reservatie? volgende) GeefVorigeEnVolgendeReservatie(int autoId, DateTime tijdstip);

    }
}

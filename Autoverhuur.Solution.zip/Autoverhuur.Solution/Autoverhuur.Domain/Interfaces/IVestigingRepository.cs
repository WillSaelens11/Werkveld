﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Domain.Interfaces
{
    public interface IVestigingRepository
    {
        List<Vestiging> GeefAlleVestigingen();
        void VoegVestigingToe(Vestiging vestiging);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Domain.Models
{
    public class Auto
    {
        public int Id { get; private set; }
        public string Nummerplaat { get; private set; }
        public string Model { get; private set; }
        public int Zitplaatsen { get; private set; }
        public string Motortype { get; private set; }
        public int VestigingId { get; private set; }

        private static readonly string[] GeldigeMotortypes = { "Benzine", "Diesel", "Elektrisch", "Hybride" };

        public Auto(string nummerplaat, string model, int zitplaatsen, string motortype, int vestigingId)
            : this(0, nummerplaat, model, zitplaatsen, motortype, vestigingId)
        {
        }

        public Auto(int id, string nummerplaat, string model, int zitplaatsen, string motortype, int vestigingId)
        {
            if (string.IsNullOrWhiteSpace(nummerplaat))
                throw new AutoException("Nummerplaat mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(model))
                throw new AutoException("Model mag niet leeg zijn.");
            if (zitplaatsen < 2)
                throw new AutoException("Zitplaatsen moet minstens 2 zijn.");
            if (!GeldigeMotortypes.Contains(motortype))
                throw new AutoException($"Ongeldig motortype: {motortype} (toegestaan: {string.Join(", ", GeldigeMotortypes)})");

            Id = id;
            Nummerplaat = nummerplaat;
            Model = model;
            Zitplaatsen = zitplaatsen;
            Motortype = motortype;
            VestigingId = vestigingId;
        }
    }
}



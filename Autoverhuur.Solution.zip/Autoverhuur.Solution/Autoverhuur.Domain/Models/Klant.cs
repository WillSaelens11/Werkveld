﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Domain.Models
{
    public class Klant
    {
        public int Id { get; private set; }
        public string Voornaam { get; }
        public string Achternaam { get; }
        public string Email { get; }
        public string Straat { get; }
        public string Postcode { get; }
        public string Woonplaats { get; }
        public string Land { get; }

        // ✅ Toegevoegd: volledige naam als leesbare eigenschap
        public string VolledigeNaam => $"{Voornaam} {Achternaam}";

        // Constructor voor nieuwe klanten (zonder Id)
        public Klant(string voornaam, string achternaam, string email, string straat, string postcode, string woonplaats, string land)
            : this(0, voornaam, achternaam, email, straat, postcode, woonplaats, land)
        {
        }

        // Constructor voor bestaande klanten (met Id)
        public Klant(int id, string voornaam, string achternaam, string email, string straat, string postcode, string woonplaats, string land)
        {
            if (string.IsNullOrWhiteSpace(voornaam))
                throw new KlantException("Voornaam mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(achternaam))
                throw new KlantException("Achternaam mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(email))
                throw new KlantException("Email mag niet leeg zijn.");
            if (!IsGeldigEmail(email))
                throw new KlantException($"Email '{email}' is ongeldig.");
            if (string.IsNullOrWhiteSpace(straat))
                throw new KlantException("Straat mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(postcode))
                throw new KlantException("Postcode mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(woonplaats))
                throw new KlantException("Woonplaats mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(land))
                throw new KlantException("Land mag niet leeg zijn.");

            Id = id;
            Voornaam = voornaam;
            Achternaam = achternaam;
            Email = email;
            Straat = straat;
            Postcode = postcode;
            Woonplaats = woonplaats;
            Land = land;
        }

        private bool IsGeldigEmail(string email)
        {
            if (!email.Contains('@') || email.IndexOf('@') < 3)
                return false;

            string[] delen = email.Split('@');
            if (delen.Length != 2) return false;

            string domein = delen[1];
            int laatstePunt = domein.LastIndexOf('.');
            if (laatstePunt == -1 || laatstePunt >= domein.Length - 2 || laatstePunt <= 0)
                return false;

            return true;
        }
    }
}




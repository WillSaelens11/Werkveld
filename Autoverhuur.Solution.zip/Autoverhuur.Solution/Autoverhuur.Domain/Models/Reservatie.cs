﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Domain.Models
{
    public class Reservatie
    {
        public int Id { get; }
        public int KlantId { get; }
        public int AutoId { get; }
        public int VestigingId { get; }
        public DateTime StartDatum { get; }
        public DateTime EindDatum { get; }

        // Constructor voor nieuwe reservatie (zonder Id)
        public Reservatie(int klantId, int autoId, int vestigingId, DateTime startDatum, DateTime eindDatum)
            : this(0, klantId, autoId, vestigingId, startDatum, eindDatum)
        {
        }

        // Constructor voor bestaande reservatie (met Id)
        public Reservatie(int id, int klantId, int autoId, int vestigingId, DateTime startDatum, DateTime eindDatum)
        {
            if (klantId <= 0)
                throw new ReservatieException("KlantId moet groter zijn dan 0.");
            if (autoId <= 0)
                throw new ReservatieException("AutoId moet groter zijn dan 0.");
            if (vestigingId <= 0)
                throw new ReservatieException("VestigingId moet groter zijn dan 0.");

            if (startDatum <= DateTime.Now)
                throw new ReservatieException("De startdatum moet in de toekomst liggen.");
            if (eindDatum <= startDatum)
                throw new ReservatieException("De einddatum moet later zijn dan de startdatum.");
            if ((eindDatum - startDatum).TotalDays < 1)
                throw new ReservatieException("De huurperiode moet minstens 1 dag zijn.");

            Id = id;
            KlantId = klantId;
            AutoId = autoId;
            VestigingId = vestigingId;
            StartDatum = startDatum;
            EindDatum = eindDatum;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Domain.Models
{
    public class Vestiging
    {
        public int Id { get; }
        public string Luchthaven { get; }
        public string Straat { get; }
        public string Postcode { get; }
        public string Plaats { get; }
        public string Land { get; }

        // Constructor voor nieuwe vestiging (zonder Id)
        public Vestiging(string luchthaven, string straat, string postcode, string plaats, string land)
            : this(0, luchthaven, straat, postcode, plaats, land)
        {
        }

        // Constructor voor bestaande vestiging (met Id)
        public Vestiging(int id, string luchthaven, string straat, string postcode, string plaats, string land)
        {
            if (string.IsNullOrWhiteSpace(luchthaven))
                throw new VestigingException("Luchthaven mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(straat))
                throw new VestigingException("Straat mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(postcode))
                throw new VestigingException("Postcode mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(plaats))
                throw new VestigingException("Plaats mag niet leeg zijn.");
            if (string.IsNullOrWhiteSpace(land))
                throw new VestigingException("Land mag niet leeg zijn.");

            Id = id;
            Luchthaven = luchthaven;
            Straat = straat;
            Postcode = postcode;
            Plaats = plaats;
            Land = land;
        }
    }
}


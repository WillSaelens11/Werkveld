﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Gegevens.Importers
{
    public class AutoImporter
    {
        private readonly DomainManager _manager;

        public AutoImporter(DomainManager manager)
        {
            _manager = manager;
        }

        public void Importeer(string pad)
        {
            Console.WriteLine($"📥 Bestand geselecteerd: {Path.GetFileName(pad)}");

            int success = 0, fouten = 0, lijnNr = 0;

            // Foutbestand opslaan in dezelfde map onder FouteImporten/
            string foutFolder = Path.Combine(Path.GetDirectoryName(pad)!, "FouteImporten");
            Directory.CreateDirectory(foutFolder);
            string foutbestandPad = Path.Combine(foutFolder, "fouten_autos.csv");

            using var writer = new StreamWriter(foutbestandPad);
            writer.WriteLine("Bestand;LijnNr;Foutmelding");

            using var reader = new StreamReader(pad);

            // ✅ Header controleren
            if (!reader.EndOfStream)
            {
                lijnNr++;
                string header = reader.ReadLine();
                if (header?.Trim() != "Nummerplaat;Model;Zitplaatsen;Motortype")
                {
                    Console.WriteLine("❌ Foutieve header.");
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};Header ongeldig: {header}");
                    return;
                }
            }

            var vestigingen = _manager.GeefAlleVestigingen().ToList();
            if (vestigingen.Count == 0)
            {
                Console.WriteLine("❌ Geen vestigingen gevonden in database.");
                return;
            }

            int index = 0;

            while (!reader.EndOfStream)
            {
                lijnNr++;
                string lijn = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(lijn)) continue;

                try
                {
                    string[] d = lijn.Split(';');
                    if (d.Length != 4)
                        throw new FormatException("Verwacht 4 velden: Nummerplaat;Model;Zitplaatsen;Motortype");

                    var vestigingId = vestigingen[index % vestigingen.Count].Id;
                    index++;

                    var auto = new Auto(
                        nummerplaat: d[0].Trim(),
                        model: d[1].Trim(),
                        zitplaatsen: int.Parse(d[2]),
                        motortype: d[3].Trim(),
                        vestigingId: vestigingId
                    );

                    _manager.VoegAutoToe(auto);
                    success++;
                }
                catch (Exception ex)
                {
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};{ex.Message}");
                    fouten++;
                }
            }

            Console.WriteLine($"✅ Auto's geïmporteerd: {success}");
            Console.WriteLine($"⚠️ Fouten: {fouten} → zie {foutbestandPad}");
        }
    }
}

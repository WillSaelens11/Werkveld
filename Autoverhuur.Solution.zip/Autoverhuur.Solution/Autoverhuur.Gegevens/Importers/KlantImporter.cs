﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Gegevens.Importers
{
    public class KlantImporter
    {
        private readonly DomainManager _manager;

        public KlantImporter(DomainManager manager)
        {
            _manager = manager;
        }

        public void Importeer(string pad)
        {
            Console.WriteLine($"📥 Bestand geselecteerd: {Path.GetFileName(pad)}");

            int success = 0, fouten = 0, lijnNr = 0;
            string foutFolder = Path.Combine(Path.GetDirectoryName(pad)!, "FouteImporten");
            Directory.CreateDirectory(foutFolder);
            string foutbestandPad = Path.Combine(foutFolder, "fouten_klanten.csv");


            using var writer = new StreamWriter(foutbestandPad);
            writer.WriteLine("Bestand;LijnNr;Foutmelding");

            using var reader = new StreamReader(pad);

            // Header controleren
            if (!reader.EndOfStream)
            {
                lijnNr++;
                string header = reader.ReadLine();
                if (header?.Trim() != "Voornaam;Achternaam;Email;Straat;Postcode;Woonplaats;Land")
                {
                    Console.WriteLine("❌ Foutieve header in CSV-bestand.");
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};Header ongeldig: {header}");
                    return;
                }
            }

            while (!reader.EndOfStream)
            {
                lijnNr++;
                string lijn = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(lijn)) continue;

                try
                {
                    string[] delen = lijn.Split(';');
                    if (delen.Length != 7)
                        throw new FormatException("Verwacht 7 velden: Voornaam;Achternaam;Email;Straat;Postcode;Woonplaats;Land");

                    var klant = new Klant(
                        voornaam: delen[0].Trim(),
                        achternaam: delen[1].Trim(),
                        email: delen[2].Trim(),
                        straat: delen[3].Trim(),
                        postcode: delen[4].Trim(),
                        woonplaats: delen[5].Trim(),
                        land: delen[6].Trim()
                    );

                    _manager.VoegKlantToe(klant);
                    success++;
                }
                catch (Exception ex)
                {
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};{ex.Message}");
                    fouten++;
                }
            }

            Console.WriteLine($"✅ Geïmporteerde klanten: {success}");
            Console.WriteLine($"⚠️ Fouten: {fouten} → zie {foutbestandPad}");
        }
    }
}

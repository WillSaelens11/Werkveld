﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Gegevens.Importers     // IN GEVAL DAT MEN EEN RESERVATIEBESTAND KRIJGEN MET AL GEMAAKTE RESERVATIES.
{
    public class ReservatieImporter
    {
        private readonly DomainManager _manager;

        public ReservatieImporter(DomainManager manager)
        {
            _manager = manager;
        }

        public void Importeer(string pad)
        {
            Console.WriteLine($"📥 Bestand geselecteerd: {Path.GetFileName(pad)}");

            int success = 0, fouten = 0, lijnNr = 0;
            string foutFolder = Path.Combine(Path.GetDirectoryName(pad)!, "FouteImporten");
            Directory.CreateDirectory(foutFolder);
            string foutbestandPad = Path.Combine(foutFolder, "fouten_klanten.csv");


            using var writer = new StreamWriter(foutbestandPad);
            writer.WriteLine("Bestand;LijnNr;Foutmelding");

            using var reader = new StreamReader(pad);

            if (!reader.EndOfStream)
            {
                lijnNr++;
                string header = reader.ReadLine();
                if (header?.Trim() != "KlantId;AutoId;VestigingId;StartDatum;EindDatum")
                {
                    Console.WriteLine("❌ Foutieve header.");
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};Header ongeldig: {header}");
                    return;
                }
            }

            var klantIds = _manager.GeefAlleKlanten().Select(k => k.Id).ToHashSet();
            var autoIds = _manager.GeefAlleAutos().Select(a => a.Id).ToHashSet();
            var vestigingIds = _manager.GeefAlleVestigingen().Select(v => v.Id).ToHashSet();

            while (!reader.EndOfStream)
            {
                lijnNr++;
                string lijn = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(lijn)) continue;

                try
                {
                    var d = lijn.Split(';');
                    if (d.Length != 5) throw new FormatException("Verwacht 5 velden");

                    int klantId = int.Parse(d[0]), autoId = int.Parse(d[1]), vestigingId = int.Parse(d[2]);
                    DateTime start = DateTime.Parse(d[3]), eind = DateTime.Parse(d[4]);

                    if (!klantIds.Contains(klantId)) throw new ArgumentException($"KlantId {klantId} bestaat niet.");
                    if (!autoIds.Contains(autoId)) throw new ArgumentException($"AutoId {autoId} bestaat niet.");
                    if (!vestigingIds.Contains(vestigingId)) throw new ArgumentException($"VestigingId {vestigingId} bestaat niet.");

                    var r = new Reservatie(klantId, autoId, vestigingId, start, eind);
                    _manager.VoegReservatieToe(r);
                    success++;
                }
                catch (Exception ex)
                {
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};{ex.Message}");
                    fouten++;
                }
            }

            Console.WriteLine($"✅ Reservaties geïmporteerd: {success}");
            Console.WriteLine($"⚠️ Fouten: {fouten} → {foutbestandPad}");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Gegevens.Importers
{
    public class VestigingImporter
    {
        private readonly DomainManager _manager;

        public VestigingImporter(DomainManager manager)
        {
            _manager = manager;
        }

        public void Importeer(string pad)
        {
            Console.WriteLine($"📥 Bestand geselecteerd: {Path.GetFileName(pad)}");

            int success = 0, fouten = 0, lijnNr = 0;
            string foutFolder = Path.Combine(Path.GetDirectoryName(pad)!, "FouteImporten");
            Directory.CreateDirectory(foutFolder);
            string foutbestandPad = Path.Combine(foutFolder, "fouten_klanten.csv");


            using var writer = new StreamWriter(foutbestandPad);
            writer.WriteLine("Bestand;LijnNr;Foutmelding");

            using var reader = new StreamReader(pad);

            if (!reader.EndOfStream)
            {
                lijnNr++;
                string header = reader.ReadLine();
                if (header?.Trim() != "Luchthaven;Straat;Postcode;Plaats;Land")
                {
                    Console.WriteLine("❌ Foutieve header.");
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};Header ongeldig: {header}");
                    return;
                }
            }

            while (!reader.EndOfStream)
            {
                lijnNr++;
                string lijn = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(lijn)) continue;

                try
                {
                    var d = lijn.Split(';');
                    if (d.Length != 5) throw new FormatException("Verwacht 5 velden");

                    var v = new Vestiging(d[0].Trim(), d[1].Trim(), d[2].Trim(), d[3].Trim(), d[4].Trim());
                    _manager.VoegVestigingToe(v);
                    success++;
                }
                catch (Exception ex)
                {
                    writer.WriteLine($"{Path.GetFileName(pad)};{lijnNr};{ex.Message}");
                    fouten++;
                }
            }

            Console.WriteLine($"✅ Vestigingen geïmporteerd: {success}");
            Console.WriteLine($"⚠️ Fouten: {fouten} → {foutbestandPad}");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Persistence;
using Autoverhuur.Persistence.Repositories;
using Autoverhuur.Domain.Interfaces;
using Autoverhuur.Domain;
using Autoverhuur.Gegevens.Importers;

namespace Autoverhuur.Gegevens
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== AUTOVERHUUR CSV IMPORTER ===\n");

            // ✅ PAD AANPASSEN HIER
            string importFolder = @"C:\Users\willi\source\repos\Autoverhuur.Solution\AutoverhuurImport";

            if (!Directory.Exists(importFolder))
            {
                Console.WriteLine($"❌ Map niet gevonden: {importFolder}");
                return;
            }

            // Setup
            string connectionString = DbInfo.ConnectionString;
            var manager = new DomainManager(
                new KlantRepository(new KlantMapper(connectionString)),
                new VestigingRepository(new VestigingMapper(connectionString)),
                new AutoRepository(new AutoMapper(connectionString)),
                new ReservatieRepository(new ReservatieMapper(connectionString))
            );

            while (true)
            {
                Console.WriteLine($"\n📁 Beschikbare CSV-bestanden in: {importFolder}\n");

                string[] bestanden = Directory.GetFiles(importFolder, "*.csv");
                if (bestanden.Length == 0)
                {
                    Console.WriteLine("⚠️ Geen .csv-bestanden gevonden.");
                    break;
                }

                for (int i = 0; i < bestanden.Length; i++)
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(bestanden[i])}");

                Console.WriteLine("0. Afsluiten");
                Console.Write("\nKies een nummer om te importeren: ");
                string input = Console.ReadLine();

                if (input == "0") break;

                if (!int.TryParse(input, out int keuze) || keuze < 1 || keuze > bestanden.Length)
                {
                    Console.WriteLine("❌ Ongeldige keuze.");
                    continue;
                }

                string pad = bestanden[keuze - 1];
                string bestandsNaam = Path.GetFileName(pad).ToLower();

                try
                {
                    if (bestandsNaam.Contains("vestiging"))
                        new VestigingImporter(manager).Importeer(pad);
                    else if (bestandsNaam.Contains("klant"))
                        new KlantImporter(manager).Importeer(pad);
                    else if (bestandsNaam.Contains("auto"))
                        new AutoImporter(manager).Importeer(pad);
                    else if (bestandsNaam.Contains("reservatie"))
                        new ReservatieImporter(manager).Importeer(pad);
                    else
                        Console.WriteLine("⚠️ Geen geschikte importer gevonden op basis van bestandsnaam.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Fout tijdens import: {ex.Message}");
                }
            }

            Console.WriteLine("\n⏹️  Importprogramma afgesloten.");
        }
    }
}



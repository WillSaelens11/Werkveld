﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoverhuur.Persistence
{
    public static class DbInfo
    {
        public const string ConnectionString =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\willi\source\repos\Autoverhuur.Solution\Autoverhuur.mdf;Integrated Security=True;Connect Timeout=30;";
    }
}

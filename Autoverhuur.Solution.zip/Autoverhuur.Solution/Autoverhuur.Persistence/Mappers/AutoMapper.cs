﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Data.SqlClient;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Persistence
{
    public class AutoMapper
    {
        private readonly string _connectionString;

        public AutoMapper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Auto> GeefAlleAutos()
        {
            var autos = new List<Auto>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT Id, Nummerplaat, Model, Zitplaatsen, Motortype, VestigingId 
                    FROM Autos
                ";

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var auto = new Auto(
                                id: (int)reader["Id"],
                                nummerplaat: (string)reader["Nummerplaat"],
                                model: (string)reader["Model"],
                                zitplaatsen: (int)reader["Zitplaatsen"],
                                motortype: (string)reader["Motortype"],
                                vestigingId: (int)reader["VestigingId"]
                            );

                            autos.Add(auto);
                        }
                        catch (AutoException ex)
                        {
                            Console.WriteLine($"Fout bij laden auto: {ex.Message}");
                        }
                    }
                }
            }

            return autos;
        }

        public void VoegAutoToe(Auto auto)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO Autos (Nummerplaat, Model, Zitplaatsen, Motortype, VestigingId)
                    VALUES (@nummerplaat, @model, @zitplaatsen, @motortype, @vestigingId)
                ";

                cmd.Parameters.AddWithValue("@nummerplaat", auto.Nummerplaat);
                cmd.Parameters.AddWithValue("@model", auto.Model);
                cmd.Parameters.AddWithValue("@zitplaatsen", auto.Zitplaatsen);
                cmd.Parameters.AddWithValue("@motortype", auto.Motortype);
                cmd.Parameters.AddWithValue("@vestigingId", auto.VestigingId);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Auto> GeefBeschikbareAutos(int vestigingId, DateTime start, DateTime eind)
        {
            List<Auto> autos = new();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
            SELECT a.Id, a.Nummerplaat, a.Model, a.Zitplaatsen, a.Motortype, a.VestigingId
            FROM Autos a
            WHERE a.VestigingId = @vestigingId
              AND a.Id NOT IN (
                  SELECT r.AutoId
                  FROM Reservaties r
                  WHERE NOT (r.EindDatum <= @start OR r.StartDatum >= @eind)
              )";

                cmd.Parameters.AddWithValue("@vestigingId", vestigingId);
                cmd.Parameters.AddWithValue("@start", start);
                cmd.Parameters.AddWithValue("@eind", eind);

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var auto = new Auto(
                                id: (int)reader["Id"],
                                nummerplaat: (string)reader["Nummerplaat"],
                                model: (string)reader["Model"],
                                zitplaatsen: (int)reader["Zitplaatsen"],
                                motortype: (string)reader["Motortype"],
                                vestigingId: (int)reader["VestigingId"]
                            );

                            autos.Add(auto);
                        }
                        catch
                        {
                            // Ongeldige auto overslaan
                        }
                    }
                }
            }

            return autos;
        }
    }
}

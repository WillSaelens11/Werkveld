﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Persistence
{
    public class KlantMapper
    {
        private readonly string _connectionString;

        public KlantMapper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Klant> GeefAlleKlanten()
        {
            var klanten = new List<Klant>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT Id, Voornaam, Achternaam, Email, Straat, Postcode, Woonplaats, Land 
                    FROM Klanten
                ";

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var klant = new Klant(
                                id: (int)reader["Id"],
                                voornaam: (string)reader["Voornaam"],
                                achternaam: (string)reader["Achternaam"],
                                email: (string)reader["Email"],
                                straat: (string)reader["Straat"],
                                postcode: (string)reader["Postcode"],
                                woonplaats: (string)reader["Woonplaats"],
                                land: (string)reader["Land"]
                            );

                            klanten.Add(klant);
                        }
                        catch (KlantException ex)
                        {
                            Console.WriteLine($"Fout bij laden klant: {ex.Message}");
                        }
                    }
                }
            }

            return klanten;
        }

        public void VoegKlantToe(Klant klant)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO Klanten (Voornaam, Achternaam, Email, Straat, Postcode, Woonplaats, Land)
                    VALUES (@voornaam, @achternaam, @email, @straat, @postcode, @woonplaats, @land)
                ";

                cmd.Parameters.AddWithValue("@voornaam", klant.Voornaam);
                cmd.Parameters.AddWithValue("@achternaam", klant.Achternaam);
                cmd.Parameters.AddWithValue("@email", klant.Email);
                cmd.Parameters.AddWithValue("@straat", klant.Straat);
                cmd.Parameters.AddWithValue("@postcode", klant.Postcode);
                cmd.Parameters.AddWithValue("@woonplaats", klant.Woonplaats);
                cmd.Parameters.AddWithValue("@land", klant.Land);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public Klant GeefKlant(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Klanten WHERE Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            conn.Open();

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Klant(
                    id: (int)reader["Id"],
                    voornaam: (string)reader["Voornaam"],
                    achternaam: (string)reader["Achternaam"],
                    email: (string)reader["Email"],
                    straat: (string)reader["Straat"],
                    postcode: (string)reader["Postcode"],
                    woonplaats: (string)reader["Woonplaats"],
                    land: (string)reader["Land"]
                );
            }

            throw new Exception($"Klant met Id={id} niet gevonden.");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Persistence
{
    public class ReservatieMapper
    {
        private readonly string _connectionString;

        public ReservatieMapper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Reservatie> GeefAlleReservaties()
        {
            var reservaties = new List<Reservatie>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT Id, KlantId, AutoId, VestigingId, StartDatum, EindDatum 
                    FROM Reservaties
                ";

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var reservatie = new Reservatie(
                                id: (int)reader["Id"],
                                klantId: (int)reader["KlantId"],
                                autoId: (int)reader["AutoId"],
                                vestigingId: (int)reader["VestigingId"],
                                startDatum: (DateTime)reader["StartDatum"],
                                eindDatum: (DateTime)reader["EindDatum"]
                            );

                            reservaties.Add(reservatie);
                        }
                        catch (ReservatieException ex)
                        {
                            Console.WriteLine($"Fout bij laden reservatie: {ex.Message}");
                        }
                    }
                }
            }

            return reservaties;
        }

        public int VoegReservatieToe(Reservatie reservatie)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO Reservaties (KlantId, AutoId, VestigingId, StartDatum, EindDatum)
                    VALUES (@klantId, @autoId, @vestigingId, @startDatum, @eindDatum);
                    SELECT SCOPE_IDENTITY();
                ";

                cmd.Parameters.AddWithValue("@klantId", reservatie.KlantId);
                cmd.Parameters.AddWithValue("@autoId", reservatie.AutoId);
                cmd.Parameters.AddWithValue("@vestigingId", reservatie.VestigingId);
                cmd.Parameters.AddWithValue("@startDatum", reservatie.StartDatum);
                cmd.Parameters.AddWithValue("@eindDatum", reservatie.EindDatum);

                conn.Open();
                int gegenereerdId = Convert.ToInt32(cmd.ExecuteScalar());
                return gegenereerdId;
            }
        }


        //public List<Auto> GeefBeschikbareAutos(int vestigingId, DateTime start, DateTime eind)
        //{
        //    List<Auto> autos = new();

        //    using (var conn = new SqlConnection(_connectionString))
        //    using (var cmd = conn.CreateCommand())
        //    {
        //        cmd.CommandText = @"
        //    SELECT a.Id, a.Nummerplaat, a.Model, a.Zitplaatsen, a.Motortype, a.VestigingId
        //    FROM Autos a
        //    WHERE a.VestigingId = @vestigingId
        //      AND a.Id NOT IN (
        //          SELECT r.AutoId
        //          FROM Reservaties r
        //          WHERE NOT (r.EindDatum <= @start OR r.StartDatum >= @eind)
        //      )";

        //        cmd.Parameters.AddWithValue("@vestigingId", vestigingId);
        //        cmd.Parameters.AddWithValue("@start", start);
        //        cmd.Parameters.AddWithValue("@eind", eind);

        //        conn.Open();
        //        using (var reader = cmd.ExecuteReader())
        //        {
        //            while (reader.Read())
        //            {
        //                try
        //                {
        //                    var auto = new Auto(
        //                        id: (int)reader["Id"],
        //                        nummerplaat: (string)reader["Nummerplaat"],
        //                        model: (string)reader["Model"],
        //                        zitplaatsen: (int)reader["Zitplaatsen"],
        //                        motortype: (string)reader["Motortype"],
        //                        vestigingId: (int)reader["VestigingId"]
        //                    );

        //                    autos.Add(auto);
        //                }
        //                catch
        //                {
        //                    // Ongeldige auto overslaan
        //                }
        //            }
        //        }
        //    }

        //    return autos;
        //}

        public List<Reservatie> ZoekReservaties(string klantnaam, DateTime? datum, int? vestigingId)
        {
            List<Reservatie> reservaties = new();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                var filters = new List<string>();
                if (!string.IsNullOrWhiteSpace(klantnaam))
                    filters.Add("k.Voornaam + ' ' + k.Achternaam LIKE @klantnaam");

                if (datum.HasValue)
                    filters.Add("@datum BETWEEN r.StartDatum AND r.EindDatum");

                if (vestigingId.HasValue)
                    filters.Add("r.VestigingId = @vestigingId");

                string whereClause = filters.Count > 0 ? "WHERE " + string.Join(" AND ", filters) : "";

                cmd.CommandText = $@"
            SELECT r.Id, r.KlantId, r.AutoId, r.VestigingId, r.StartDatum, r.EindDatum
            FROM Reservaties r
            INNER JOIN Klanten k ON r.KlantId = k.Id
            {whereClause}";

                if (!string.IsNullOrWhiteSpace(klantnaam))
                    cmd.Parameters.AddWithValue("@klantnaam", $"%{klantnaam}%");
                if (datum.HasValue)
                    cmd.Parameters.AddWithValue("@datum", datum.Value);
                if (vestigingId.HasValue)
                    cmd.Parameters.AddWithValue("@vestigingId", vestigingId.Value);

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var reservatie = new Reservatie(
                                id: (int)reader["Id"],
                                klantId: (int)reader["KlantId"],
                                autoId: (int)reader["AutoId"],
                                vestigingId: (int)reader["VestigingId"],
                                startDatum: (DateTime)reader["StartDatum"],
                                eindDatum: (DateTime)reader["EindDatum"]
                            );

                            reservaties.Add(reservatie);
                        }
                        catch
                        {
                            // overslaan als data niet correct is
                        }
                    }
                }
            }

            return reservaties;
        }

        public void VerwijderReservatie(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Reservaties WHERE Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public (Reservatie? vorige, Reservatie? volgende) GeefVorigeEnVolgendeReservatie(int autoId, DateTime tijdstip)
        {
            Reservatie? vorige = null;
            Reservatie? volgende = null;

            using var conn = new SqlConnection(_connectionString);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT TOP 1 * FROM Reservaties
                WHERE AutoId = @autoId AND EindDatum < @tijdstip
                ORDER BY EindDatum DESC;

                SELECT TOP 1 * FROM Reservaties
                WHERE AutoId = @autoId AND StartDatum > @tijdstip
                ORDER BY StartDatum ASC;";

            cmd.Parameters.AddWithValue("@autoId", autoId);
            cmd.Parameters.AddWithValue("@tijdstip", tijdstip);

            conn.Open();

            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                vorige = new Reservatie(
                    id: (int)reader["Id"],
                    klantId: (int)reader["KlantId"],
                    autoId: (int)reader["AutoId"],
                    vestigingId: (int)reader["VestigingId"],
                    startDatum: (DateTime)reader["StartDatum"],
                    eindDatum: (DateTime)reader["EindDatum"]
                );
            }

            if (reader.NextResult() && reader.Read())
            {
                volgende = new Reservatie(
                    id: (int)reader["Id"],
                    klantId: (int)reader["KlantId"],
                    autoId: (int)reader["AutoId"],
                    vestigingId: (int)reader["VestigingId"],
                    startDatum: (DateTime)reader["StartDatum"],
                    eindDatum: (DateTime)reader["EindDatum"]
                );
            }

            return (vorige, volgende);
        }


        public void Verwijder(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Reservaties WHERE Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

    }
}

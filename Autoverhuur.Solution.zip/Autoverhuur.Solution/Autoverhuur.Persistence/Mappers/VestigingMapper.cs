﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Exceptions;

namespace Autoverhuur.Persistence
{
    public class VestigingMapper
    {
        private readonly string _connectionString;

        public VestigingMapper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Vestiging> GeefAlleVestigingen()
        {
            var vestigingen = new List<Vestiging>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT Id, Luchthaven, Straat, Postcode, Plaats, Land 
                    FROM Vestigingen
                ";

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        try
                        {
                            var vestiging = new Vestiging(
                                id: (int)reader["Id"],
                                luchthaven: (string)reader["Luchthaven"],
                                straat: (string)reader["Straat"],
                                postcode: (string)reader["Postcode"],
                                plaats: (string)reader["Plaats"],
                                land: (string)reader["Land"]
                            );

                            vestigingen.Add(vestiging);
                        }
                        catch (VestigingException ex)
                        {
                            Console.WriteLine($"Fout bij laden vestiging: {ex.Message}");
                        }
                    }
                }
            }

            return vestigingen;
        }

        public void VoegVestigingToe(Vestiging vestiging)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO Vestigingen (Luchthaven, Straat, Postcode, Plaats, Land)
                    VALUES (@luchthaven, @straat, @postcode, @plaats, @land)
                ";

                cmd.Parameters.AddWithValue("@luchthaven", vestiging.Luchthaven);
                cmd.Parameters.AddWithValue("@straat", vestiging.Straat);
                cmd.Parameters.AddWithValue("@postcode", vestiging.Postcode);
                cmd.Parameters.AddWithValue("@plaats", vestiging.Plaats);
                cmd.Parameters.AddWithValue("@land", vestiging.Land);

                conn.Open();
                cmd.ExecuteNonQuery(); // We vragen voorlopig geen Id terug
            }
        }
    }
}

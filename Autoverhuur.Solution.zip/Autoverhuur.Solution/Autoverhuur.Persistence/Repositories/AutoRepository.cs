﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Interfaces;

namespace Autoverhuur.Persistence.Repositories
{
    public class AutoRepository : IAutoRepository
    {
        private readonly AutoMapper _mapper;

        public AutoRepository(AutoMapper mapper)
        {
            _mapper = mapper;
        }

        public List<Auto> GeefAlleAutos()
        {
            return _mapper.GeefAlleAutos();
        }

        public void VoegAutoToe(Auto auto)
        {
            _mapper.VoegAutoToe(auto);
        }

        public List<Auto> GeefBeschikbareAutos(int vestigingId, DateTime start, DateTime eind)
        {
            return _mapper.GeefBeschikbareAutos(vestigingId, start, eind);
        }

    }
}

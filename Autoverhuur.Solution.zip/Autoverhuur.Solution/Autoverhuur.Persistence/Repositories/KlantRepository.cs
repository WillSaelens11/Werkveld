﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Interfaces;

namespace Autoverhuur.Persistence.Repositories
{
    public class KlantRepository : IKlantRepository
    {
        private readonly KlantMapper _mapper;

        public KlantRepository(KlantMapper mapper)
        {
            _mapper = mapper;
        }

        public List<Klant> GeefAlleKlanten()
        {
            return _mapper.GeefAlleKlanten();
        }

        public void VoegKlantToe(Klant klant)
        {
            _mapper.VoegKlantToe(klant);
        }

        public Klant GeefKlant(int id)
        {
            return _mapper.GeefKlant(id);
        }

    }
}

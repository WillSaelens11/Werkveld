﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Interfaces;

namespace Autoverhuur.Persistence.Repositories
{
    public class ReservatieRepository : IReservatieRepository
    {
        private readonly ReservatieMapper _mapper;

        public ReservatieRepository(ReservatieMapper mapper)
        {
            _mapper = mapper;
        }

        public List<Reservatie> GeefAlleReservaties()
        {
            return _mapper.GeefAlleReservaties();
        }

        public int VoegReservatieToe(Reservatie reservatie)
        {
            return _mapper.VoegReservatieToe(reservatie);
        }

        // Indien je later reservaties wil zoeken of verwijderen
        public List<Reservatie> ZoekReservaties(string klantnaam, DateTime? datum, int? vestigingId)
        {
            return _mapper.ZoekReservaties(klantnaam, datum, vestigingId);
        }

        public void VerwijderReservatie(int id)
        {
            _mapper.VerwijderReservatie(id);
        }

        public (Reservatie? vorige, Reservatie? volgende) GeefVorigeEnVolgendeReservatie(int autoId, DateTime tijdstip)
        {
            return _mapper.GeefVorigeEnVolgendeReservatie(autoId, tijdstip);
        }
    }
}

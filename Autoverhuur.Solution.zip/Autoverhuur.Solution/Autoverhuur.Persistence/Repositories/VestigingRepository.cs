﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autoverhuur.Domain.Models;
using Autoverhuur.Domain.Interfaces;

namespace Autoverhuur.Persistence.Repositories
{
    public class VestigingRepository : IVestigingRepository
    {
        private readonly VestigingMapper _mapper;

        public VestigingRepository(VestigingMapper mapper)
        {
            _mapper = mapper;
        }

        public List<Vestiging> GeefAlleVestigingen()
        {
            return _mapper.GeefAlleVestigingen();
        }

        public void VoegVestigingToe(Vestiging vestiging)
        {
            _mapper.VoegVestigingToe(vestiging);
        }
    }
}

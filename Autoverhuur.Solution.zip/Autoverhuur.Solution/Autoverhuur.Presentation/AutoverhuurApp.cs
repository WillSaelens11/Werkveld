﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using Autoverhuur.Presentation.Windows;

namespace Autoverhuur.Presentation
{
    public class AutoverhuurApp
    {
        private readonly DomainManager _manager;
        public Klant IngelogdeKlant { get; set; }
        public AutoverhuurApp(DomainManager manager)
        {
            _manager = manager;
        }


        public void Start()
        {
            var main = new MainWindow(_manager, this);
            main.Show();

        }
    }
}

﻿using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;


namespace Autoverhuur.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for Auto.xaml
    /// </summary>
    public partial class AutoWindow : Window
    {
        private readonly DomainManager _manager;
        private List<Auto> _alleAutos;
        private List<Vestiging> _vestigingen;

        public AutoWindow(DomainManager manager)
        {
            InitializeComponent();
            _manager = manager;

            _alleAutos = _manager.GeefAlleAutos();
            _vestigingen = _manager.GeefAlleVestigingen();

            ToonAutos(_alleAutos);
        }

        private void ToonAutos(List<Auto> autos)
        {
            var overzicht = autos.Select(auto =>
            {
                var vestiging = _vestigingen.FirstOrDefault(v => v.Id == auto.VestigingId);
                string locatie = vestiging != null ? vestiging.Luchthaven : "Onbekend";

                return $"{auto.Nummerplaat} - {auto.Model} - {auto.Zitplaatsen} zitpl. - {auto.Motortype} ({locatie})";
            }).ToList();

            lstAutos.ItemsSource = overzicht;
        }

        private void txtFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filter = txtFilter.Text.Trim().ToLower();

            var gefilterd = _alleAutos.Where(a =>
                a.Model.ToLower().Contains(filter) ||
                a.Nummerplaat.ToLower().Contains(filter)).ToList();

            ToonAutos(gefilterd);
        }
    }
}

﻿using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Autoverhuur.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for Klant.xaml
    /// </summary>
    public partial class KlantWindow : Window
    {
        private readonly DomainManager _manager;
        private List<Klant> _alleKlanten;

        public Klant GeselecteerdeKlant { get; private set; }

        public KlantWindow(DomainManager manager)
        {
            InitializeComponent();
            _manager = manager;

            _alleKlanten = _manager.GeefAlleKlanten();
            lstKlanten.ItemsSource = _alleKlanten;
        }

        private void txtZoek_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = txtZoek.Text.Trim().ToLower();

            lstKlanten.ItemsSource = _alleKlanten
                .Where(k => k.VolledigeNaam.ToLower().Contains(filter))
                .ToList();
        }

        private void SelecteerKlant_Click(object sender, RoutedEventArgs e)
        {
            if (lstKlanten.SelectedItem is Klant klant)
            {
                GeselecteerdeKlant = klant;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Selecteer een klant uit de lijst.");
            }
        }
    }
}

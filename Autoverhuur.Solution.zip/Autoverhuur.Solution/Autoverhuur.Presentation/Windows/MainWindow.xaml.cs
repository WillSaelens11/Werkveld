﻿using Autoverhuur.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Autoverhuur.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly DomainManager _manager;
        private readonly AutoverhuurApp _app;

        public MainWindow(DomainManager manager, AutoverhuurApp app)

        {
            InitializeComponent();
            _manager = manager;
            _app = app;

            UpdateLoginStatus();
        }

        private void OpenKlantWindow_Click(object sender, RoutedEventArgs e)
        {
            var venster = new KlantWindow(_manager);
            venster.ShowDialog();
        }

        private void OpenOverzichtWindow_Click(object sender, RoutedEventArgs e)
        {
            var window = new OverzichtWindow(_manager);
            window.ShowDialog();
        }

        private void OpenReservatieWindow_Click(object sender, RoutedEventArgs e)
        {
            var window = new ReservatieWindow(_manager, _app);
            window.ShowDialog();
        }

        private void OpenReservatieZoekWindow_Click(object sender, RoutedEventArgs e)
        {
            var window = new ReservatieZoekWindow(_manager);
            window.ShowDialog();
        }

        private void UpdateLoginStatus()
        {
            if (_app.IngelogdeKlant != null)
            {
                txtWelkom.Text = $"👤 Ingelogd als: {_app.IngelogdeKlant.VolledigeNaam}";
                btnLoginToggle.Content = $"🔴 Uitloggen ({_app.IngelogdeKlant.Voornaam})";
            }
            else
            {
                txtWelkom.Text = "❌ Geen klant ingelogd.";
                btnLoginToggle.Content = "🟢 Klant inloggen";
            }
        }
        private void LoginToggle_Click(object sender, RoutedEventArgs e)
        {
            if (_app.IngelogdeKlant == null)
            {
                var win = new KlantWindow(_manager);
                if (win.ShowDialog() == true)
                {
                    _app.IngelogdeKlant = win.GeselecteerdeKlant;
                }
            }
            else
            {
                _app.IngelogdeKlant = null;
            }

            UpdateLoginStatus();
        }
        

    }
}

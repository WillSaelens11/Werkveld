﻿using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Autoverhuur.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for Overzicht.xaml
    /// </summary>
    public partial class OverzichtWindow : Window
    {
        private readonly DomainManager _manager;
        private List<Auto> _autos;
        private Vestiging _geselecteerdeVestiging;
        private DateTime _gekozenTijdstip;

        public OverzichtWindow(DomainManager manager)
        {
            InitializeComponent();
            _manager = manager;

            cmbVestigingen.ItemsSource = _manager.GeefAlleVestigingen();
        }
        private void OpenAutoWindow_Click(object sender, RoutedEventArgs e)
        {
            var venster = new AutoWindow(_manager);
            venster.ShowDialog();
        }
        private void ZoekAutos_Click(object sender, RoutedEventArgs e)
        {
            if (cmbVestigingen.SelectedItem is not Vestiging vestiging)
            {
                MessageBox.Show("Selecteer een vestiging.");
                return;
            }

            if (dpTijdstip.SelectedDate is not DateTime tijdstip)
            {
                MessageBox.Show("Selecteer een datum.");
                return;
            }

            _geselecteerdeVestiging = vestiging;
            _gekozenTijdstip = tijdstip;

            _autos = _manager.ZoekBeschikbareAutos(vestiging.Id, tijdstip, tijdstip.AddDays(1));

            var display = new List<string>();

            foreach (var auto in _autos)
            {
                var (vorige, volgende) = _manager.GeefVorigeEnVolgendeReservatie(auto.Id, tijdstip);

                string lijn = $"{auto.Nummerplaat} - {auto.Model}";
                if (vorige != null)
                    lijn += $" | ⏮️ {vorige.StartDatum:dd/MM} - {vorige.EindDatum:dd/MM}";
                if (volgende != null)
                    lijn += $" | ⏭️ {volgende.StartDatum:dd/MM} - {volgende.EindDatum:dd/MM}";

                display.Add(lijn);
            }

            lstAutos.ItemsSource = display;
        }

        private void GenereerMarkdown_Click(object sender, RoutedEventArgs e)
        {
            if (_autos == null || !_autos.Any())
            {
                MessageBox.Show("Er zijn geen auto's om te exporteren.");
                return;
            }

            string pad = $"Overzicht_{DateTime.Now:yyyyMMdd_HHmm}.md";
            using var writer = new StreamWriter(pad);

            writer.WriteLine("# Overzicht auto’s");
            writer.WriteLine($"**Vestiging**: {_geselecteerdeVestiging.Luchthaven}");
            writer.WriteLine($"**Tijdstip**: {_gekozenTijdstip:dd/MM/yyyy}");
            writer.WriteLine();

            foreach (var auto in _autos)
            {
                writer.WriteLine($"## {auto.Nummerplaat} - {auto.Model}");

                var (vorige, volgende) = _manager.GeefVorigeEnVolgendeReservatie(auto.Id, _gekozenTijdstip);

                if (vorige != null)
                {
                    var klant = _manager.GeefKlant(vorige.KlantId);
                    writer.WriteLine($"**Vorige reservatie**: {vorige.StartDatum:dd/MM/yyyy} → {vorige.EindDatum:dd/MM/yyyy}");
                    writer.WriteLine($"Klant: {klant.Voornaam} {klant.Achternaam}");
                    writer.WriteLine($"Adres: {klant.Straat}, {klant.Postcode} {klant.Woonplaats}, {klant.Land}");
                }

                if (volgende != null)
                {
                    var klant = _manager.GeefKlant(volgende.KlantId);
                    writer.WriteLine($"**Volgende reservatie**: {volgende.StartDatum:dd/MM/yyyy} → {volgende.EindDatum:dd/MM/yyyy}");
                    writer.WriteLine($"Klant: {klant.Voornaam} {klant.Achternaam}");
                    writer.WriteLine($"Adres: {klant.Straat}, {klant.Postcode} {klant.Woonplaats}, {klant.Land}");
                }

                if (vorige == null && volgende == null)
                {
                    writer.WriteLine("_Geen andere reservaties gevonden._");
                }

                writer.WriteLine();
            }

            MessageBox.Show($"✅ Markdown gegenereerd: {pad}");

            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = pad,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"⚠️ Kon het bestand niet automatisch openen.\n{ex.Message}");
            }
        }
    }
}

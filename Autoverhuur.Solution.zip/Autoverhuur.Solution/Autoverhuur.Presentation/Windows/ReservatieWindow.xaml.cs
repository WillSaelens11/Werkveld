﻿using Autoverhuur.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Autoverhuur.Domain.Models;

namespace Autoverhuur.Presentation.Windows
{
    public partial class ReservatieWindow : Window
    {
        private readonly DomainManager _manager;
        private Klant _geselecteerdeKlant;
        private List<Auto> _beschikbareAutos;
        private readonly AutoverhuurApp _app;

        public ReservatieWindow(DomainManager manager, AutoverhuurApp app)

        {
            InitializeComponent();
            _manager = manager;
            _app = app;

            cmbVestiging.ItemsSource = _manager.GeefAlleVestigingen();
            if (_app.IngelogdeKlant != null)
            {
                _geselecteerdeKlant = _app.IngelogdeKlant;
                txtKlant.Text = _geselecteerdeKlant.VolledigeNaam;
                
            }
        }

        private void SelecteerKlant_Click(object sender, RoutedEventArgs e)
        {
            var win = new KlantWindow(_manager);
            if (win.ShowDialog() == true)
            {
                _geselecteerdeKlant = win.GeselecteerdeKlant;
                txtKlant.Text = _geselecteerdeKlant.VolledigeNaam;
            }
        }

        private void ZoekAutos_Click(object sender, RoutedEventArgs e)
        {
            if (cmbVestiging.SelectedItem is not Vestiging vestiging)
            {
                MessageBox.Show("Selecteer een vestiging.");
                return;
            }

            if (dpStart.SelectedDate is not DateTime start || dpEinde.SelectedDate is not DateTime einde)
            {
                MessageBox.Show("Selecteer een geldige start- en einddatum.");
                return;
            }

            if (start < DateTime.Today || einde <= start || (einde - start).TotalDays < 1)
            {
                MessageBox.Show("Datums zijn ongeldig.");
                return;
            }

            int? zitplaatsen = null;
            if (int.TryParse(txtZitplaatsen.Text, out int zp))
                zitplaatsen = zp;

            _beschikbareAutos = _manager.ZoekBeschikbareAutos(vestiging.Id, start, einde);

            if (zitplaatsen.HasValue)
                _beschikbareAutos = _beschikbareAutos.Where(a => a.Zitplaatsen >= zitplaatsen).ToList();

            if (_beschikbareAutos.Count == 0)
            {
                MessageBox.Show("⚠️ Geen auto's beschikbaar voor deze zoekopdracht.");
            }

            lstAutos.ItemsSource = _beschikbareAutos.Select(a => $"{a.Nummerplaat} - {a.Model} ({a.Zitplaatsen} zitpl.)").ToList();
        }

        private void Opslaan_Click(object sender, RoutedEventArgs e)
        {
            if (_geselecteerdeKlant == null)
            {
                MessageBox.Show("Log u eerst in.");
                return;
            }

            if (cmbVestiging.SelectedItem is not Vestiging vestiging ||
                dpStart.SelectedDate is not DateTime start ||
                dpEinde.SelectedDate is not DateTime einde ||
                lstAutos.SelectedIndex == -1)
            {
                MessageBox.Show("Vul alle velden correct in.");
                return;
            }

            Auto gekozenAuto = _beschikbareAutos[lstAutos.SelectedIndex];

            try
            {
                var reservatie = new Reservatie(_geselecteerdeKlant.Id, gekozenAuto.Id, vestiging.Id, start, einde);
                _manager.VoegReservatieToe(reservatie);

                MessageBox.Show("✅ Reservatie succesvol toegevoegd.");
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Fout bij opslaan:\n{ex.Message}");
            }
        }
    }
}


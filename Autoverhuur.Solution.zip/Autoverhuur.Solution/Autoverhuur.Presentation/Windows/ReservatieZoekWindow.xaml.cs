﻿using Autoverhuur.Domain;
using Autoverhuur.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Autoverhuur.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for ReservatieZoek.xaml
    /// </summary>
    public partial class ReservatieZoekWindow : Window
    {
        private readonly DomainManager _manager;
        private List<Reservatie> _gevondenReservaties;
        private Klant _geselecteerdeKlant;

        public ReservatieZoekWindow(DomainManager manager)
        {
            InitializeComponent();
            _manager = manager;
            LaadVestigingen();
        }

        private void LaadVestigingen()
        {
            cmbVestigingen.ItemsSource = _manager.GeefAlleVestigingen();
        }


        private void SelecteerKlant_Click(object sender, RoutedEventArgs e)
        {
            var win = new KlantWindow(_manager);
            if (win.ShowDialog() == true)
            {
                _geselecteerdeKlant = win.GeselecteerdeKlant;
                txtKlantnaam.Text = _geselecteerdeKlant.VolledigeNaam;
            }
        }

        private void Zoek_Click(object sender, RoutedEventArgs e)
        {
            string naam = _geselecteerdeKlant?.VolledigeNaam;
            DateTime? datum = dpDatum.SelectedDate;
            int? vestigingId = (cmbVestigingen.SelectedItem is Vestiging v) ? v.Id : null;

            _gevondenReservaties = _manager.ZoekReservaties(naam, datum, vestigingId);

            if (_gevondenReservaties.Count == 0)

            {
                lstResultaten.ItemsSource = new[] { "Geen resultaten gevonden." };
                return;
            }

            // Toon eenvoudige samenvatting
            lstResultaten.ItemsSource = _gevondenReservaties.Select(r =>
            $"🗓️ {r.StartDatum:dd/MM/yyyy} → {r.EindDatum:dd/MM/yyyy} | Klant #{r.KlantId}, Auto #{r.AutoId}, Vestiging #{r.VestigingId}"
            ).ToList();
        }

        private void Annuleer_Click(object sender, RoutedEventArgs e)
        {
            int index = lstResultaten.SelectedIndex;
            if (index < 0 || index >= _gevondenReservaties.Count)
            {
                MessageBox.Show("Selecteer eerst een reservatie.");
                return;
            }

            var bevestiging = MessageBox.Show("Weet je zeker dat je deze reservatie wilt annuleren?", "Bevestigen", MessageBoxButton.YesNo);
            if (bevestiging != MessageBoxResult.Yes)
                return;

            var reservatie = _gevondenReservaties[index];

            try
            {
                _manager.VerwijderReservatie(reservatie.Id);
                MessageBox.Show("✅ Reservatie geannuleerd.");

                // Herlaad resultaten
                Zoek_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Fout bij verwijderen: {ex.Message}");
            }
        }

    }
}

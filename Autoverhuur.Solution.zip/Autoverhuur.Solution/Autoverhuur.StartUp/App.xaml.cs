﻿using System.Windows;
using Autoverhuur.Domain;
using Autoverhuur.Domain.Interfaces;
using Autoverhuur.Persistence;
using Autoverhuur.Persistence.Repositories;
using Autoverhuur.Presentation;
using Autoverhuur.Presentation.Windows;

namespace Autoverhuur.StartUp
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // Connectiestring ophalen uit DbInfo
            string connectionString = DbInfo.ConnectionString;

            // Mappers maken met connectiestring
            var klantMapper = new KlantMapper(connectionString);
            var vestigingMapper = new VestigingMapper(connectionString);
            var autoMapper = new AutoMapper(connectionString);
            var reservatieMapper = new ReservatieMapper(connectionString);

            // Repositories aanmaken op basis van mappers
            IKlantRepository klantRepo = new KlantRepository(klantMapper);
            IVestigingRepository vestigingRepo = new VestigingRepository(vestigingMapper);
            IAutoRepository autoRepo = new AutoRepository(autoMapper);
            IReservatieRepository reservatieRepo = new ReservatieRepository(reservatieMapper);

            // DomainManager initialiseren
            var domainManager = new DomainManager(
                klantRepo,
                vestigingRepo,
                autoRepo,
                reservatieRepo
            );

            // Presentatielaag opstarten
            var app = new AutoverhuurApp(domainManager);
            app.Start();
        }
    }
}

